package com.example.quize;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class QuizActivity extends AppCompatActivity {

    private int score = 0;
    private int correctAnswer;
    private int difficultyLevel = 1; // 초기 난이도 설정
    private boolean isGameOver = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // Intent에서 difficultyLevel 값을 받아옴
        Intent intent = getIntent();
        difficultyLevel = intent.getIntExtra("DIFFICULTY_LEVEL", 1);

        // 여기에서 사칙연산 퀴즈 등 게임 로직을 구현
        displayNewQuestion(difficultyLevel);

        // 제출 버튼 클릭 시 처리
        Button submitButton = findViewById(R.id.answerButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });

        // 타이머 시작 (30초)
        startTimer(30000);
    }

    private void startTimer(long milliseconds) {
        new CountDownTimer(milliseconds, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                TextView timerTextView = findViewById(R.id.timerTextView);
                timerTextView.setText(String.valueOf(millisUntilFinished / 1000));
            }

            @Override
            public void onFinish() {
                isGameOver = true; // 게임 종료
                showScore();
            }
        }.start();
    }

    private void showScore() {
        // 점수 화면으로 이동 및 점수 전달
        Intent intent = new Intent(this, ScoreActivity.class);
        intent.putExtra("SCORE", score);
        startActivity(intent);
        finish();
    }

    private void displayNewQuestion(int difficultyLevel) {
        // 랜덤으로 두 정수 생성
        Random random = new Random();
        int operand1, operand2;

        // 난이도에 따라 범위 설정
        switch (difficultyLevel) {
            case 1:
                operand1 = random.nextInt(5) + 1; // 1부터 5까지의 랜덤한 정수
                operand2 = random.nextInt(5) + 1;
                break;
            case 2:
                operand1 = random.nextInt(10) + 1; // 1부터 10까지의 랜덤한 정수
                operand2 = random.nextInt(10) + 1;
                break;
            case 3:
                operand1 = random.nextInt(15) + 1; // 1부터 15까지의 랜덤한 정수
                operand2 = random.nextInt(15) + 1;
                break;
            default:
                operand1 = random.nextInt(10) + 1;
                operand2 = random.nextInt(10) + 1;
        }

        // 랜덤으로 연산자 선택
        int operator = random.nextInt(4); // 0부터 3까지의 랜덤한 정수
        String operatorSymbol = "";

        // 문제와 정답 설정
        switch (operator) {
            case 0:
                correctAnswer = operand1 + operand2;
                operatorSymbol = "+";
                break;
            case 1:
                // 뺄셈에서 음수가 나오지 않도록 설정
                if (operand1 < operand2) {
                    int temp = operand1;
                    operand1 = operand2;
                    operand2 = temp;
                }
                correctAnswer = operand1 - operand2;
                operatorSymbol = "-";
                break;
            case 2:
                correctAnswer = operand1 * operand2;
                operatorSymbol = "×";
                break;
            case 3:
                if (operand2 == 0 || operand1 % operand2 != 0) {
                    // 나눗셈 문제가 유효하지 않을 경우 다시 생성
                    displayNewQuestion(difficultyLevel);
                    return;
                }
                correctAnswer = operand1 / operand2;
                operatorSymbol = "÷";
                break;
        }

        // 문제 표시
        TextView questionTextView = findViewById(R.id.questionTextView);
        questionTextView.setText(operand1 + " " + operatorSymbol + " " + operand2);
    }

    private void checkAnswer() {
        EditText answerEditText = findViewById(R.id.answerEditText);
        String userAnswerString = answerEditText.getText().toString();

        if (userAnswerString.isEmpty()) {
            Toast.makeText(this, "답을 입력하세요!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int userAnswer = Integer.parseInt(userAnswerString);
            if (userAnswer == correctAnswer) {
                score++;
                Toast.makeText(this, "정답입니다!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "오답입니다. 정답은 " + correctAnswer + " 입니다.", Toast.LENGTH_SHORT).show();
            }
            displayNewQuestion(difficultyLevel);
            answerEditText.getText().clear();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "유효한 숫자를 입력하세요.", Toast.LENGTH_SHORT).show();
        }
    }


    private void resetGame() {
        score = 0;
        isGameOver = false;
        startTimer(30000); // 새로운 타이머 시작
        displayNewQuestion(difficultyLevel);
    }

}
