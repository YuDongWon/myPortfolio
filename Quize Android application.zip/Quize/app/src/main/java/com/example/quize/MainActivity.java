package com.example.quize;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private int difficultyLevel = 1; // 기본 난이도 설정 (1: 쉬움)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 난이도 선택 버튼
        Button difficultyButton = findViewById(R.id.difficultyButton);
        difficultyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 난이도 선택 다이얼로그 띄우기
                selectDifficulty();
            }
        });

        // 게임 시작 버튼
        Button startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // QuizActivity로 이동
                startQuizActivity();
            }
        });
    }

    // QuizActivity로 이동하는 메서드
    private void startQuizActivity() {
        Intent intent = new Intent(this, QuizActivity.class);
        intent.putExtra("DIFFICULTY_LEVEL", difficultyLevel);
        startActivity(intent);
    }

    // 난이도를 선택하는 다이얼로그
    private void selectDifficulty() {
        final CharSequence[] difficultyLevels = {"쉬움", "보통", "어려움"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("난이도 선택");
        builder.setItems(difficultyLevels, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 사용자가 선택한 난이도에 따라 difficultyLevel 값을 설정
                switch (which) {
                    case 0:
                        difficultyLevel = 1; // 쉬움
                        break;
                    case 1:
                        difficultyLevel = 2; // 보통
                        break;
                    case 2:
                        difficultyLevel = 3; // 어려움
                        break;
                }

                // 사용자가 난이도를 선택했음을 알리는 토스트 메시지
                Toast.makeText(MainActivity.this, "난이도가 설정되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.show();
    }
}
