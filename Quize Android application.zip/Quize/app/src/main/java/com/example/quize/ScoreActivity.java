package com.example.quize;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ScoreActivity extends AppCompatActivity {

    private int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        // 점수를 받아와서 화면에 표시
        Intent intent = getIntent();
        score = intent.getIntExtra("SCORE", 0);

        TextView scoreTextView = findViewById(R.id.scoreTextView);
        scoreTextView.setText("점수: " + score);

        // 최고 점수를 표시
        displayHighScore();

        // 메인 화면으로 돌아가는 버튼 클릭 이벤트 설정
        Button backToMainButton = findViewById(R.id.backToMainButton);
        backToMainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToMainActivity();
            }
        });
    }

    // 메인 화면으로 돌아가는 메서드
    public void backToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish(); // 현재 액티비티 종료
    }

    // 최고 점수를 표시하는 메서드
    private void displayHighScore() {
        // SharedPreferences를 사용하여 최고 점수를 저장 및 불러오기
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        int highScore = preferences.getInt("HIGH_SCORE", 0);

        TextView highScoreTextView = findViewById(R.id.highScoreTextView);
        highScoreTextView.setText("최고 점수: " + highScore);

        // 현재 점수가 최고 점수보다 높으면 최고 점수를 갱신
        if (score > highScore) {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putInt("HIGH_SCORE", score);
            editor.apply();
        }
    }
}
