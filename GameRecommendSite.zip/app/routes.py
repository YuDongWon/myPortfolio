import os
import secrets
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_user, current_user, logout_user, login_required
from app import db, bcrypt
from app.models import User, Game, Post, Review, Purchase
from app.forms import RegistrationForm, LoginForm, AddGameForm, ReviewForm

bp = Blueprint('main', __name__)


@bp.route('/')
def home():
    if current_user.is_authenticated:
        purchased_games = current_user.purchased_games  # 현재 사용자가 구매한 게임 목록 가져오기
    else:
        purchased_games = []

    return render_template('index.html', purchased_games=purchased_games)


@bp.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You are now able to log in', 'success')
        return redirect(url_for('main.login'))
    return render_template('register.html', form=form)


@bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('main.home'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html', form=form)


@bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.home'))


def save_image(image):
    random_hex = secrets.token_hex(8)
    _, f_ext = os.path.splitext(image.filename)
    image_fn = random_hex + f_ext
    image_path = os.path.join(current_app.root_path, 'static/uploads', image_fn)

    os.makedirs(os.path.dirname(image_path), exist_ok=True)

    image.save(image_path)
    return image_fn


@bp.route('/add_game', methods=['GET', 'POST'])
@login_required
def add_game():
    form = AddGameForm()
    if form.validate_on_submit():
        if form.image.data:
            image_file = save_image(form.image.data)
        else:
            image_file = 'default.jpg'
        game = Game(
            title=form.title.data,
            image_file=image_file,
            genre=form.genre.data,
            price=form.price.data,
            description=form.description.data,
            user_id=current_user.id
        )
        db.session.add(game)
        db.session.commit()
        flash('Your game has been added!', 'success')
        return redirect(url_for('main.games'))
    return render_template('add_game.html', form=form)


@bp.route('/games', methods=['GET'])
@login_required
def games():
    query = request.args.get('query', '').strip()  # 검색어 가져오기
    if query:
        games = Game.query.filter(
            Game.title.ilike(f'%{query}%') | Game.description.ilike(f'%{query}%')
        ).all()
        message = f"Search results for: '{query}'"
    else:
        games = Game.query.all()
        message = None

    return render_template('game_list.html', games=games, message=message)



@bp.route('/recommend')
@login_required
def recommend():
    user = current_user

    ### 1. 콘텐츠 기반 필터링 ###
    # 현재 사용자가 구매한 게임의 장르를 기준으로 추천
    user_games = [purchase.game for purchase in user.purchases]  # 사용자가 구매한 게임
    user_genres = set(game.genre for game in user_games)  # 사용자가 플레이한 장르
    # 장르가 겹치는 게임 중 이미 구매하지 않은 게임 필터링
    content_based_games = Game.query.filter(Game.genre.in_(user_genres), ~Game.id.in_([game.id for game in user_games])).all()

    ### 2. 협업 필터링 ###
    # 다른 사용자 중에서 공유된 게임 기반으로 추천
    all_users = User.query.all()
    similar_users = []
    for other_user in all_users:
        if other_user.id == user.id:  # 자신과 비교하지 않음
            continue
        # 공통 구매한 게임 ID 확인
        shared_game_ids = set(purchase.game_id for purchase in user.purchases).intersection(
            set(purchase.game_id for purchase in other_user.purchases)
        )
        if shared_game_ids:
            similar_users.append(other_user)

    # 협업 필터링 추천: 비슷한 사용자가 구매한 게임 중 현재 사용자가 소유하지 않은 게임
    collaborative_games = []
    for similar_user in similar_users:
        for purchase in similar_user.purchases:
            if purchase.game.id not in [game.id for game in user_games]:
                collaborative_games.append(purchase.game)
    collaborative_games = list(set(collaborative_games))  # 중복 제거

    ### 3. 인기 기반 추천 ###
    # 평균 평점이 높은 게임 상위 5개 추천 (이미 구매한 게임 제외)
    popular_games = Game.query.outerjoin(Review).group_by(Game.id).filter(
        ~Game.id.in_([game.id for game in user_games])
    ).order_by(db.func.avg(Review.rating).desc()).limit(5).all()

    # 추천 결과를 템플릿으로 전달
    return render_template(
        'recommend.html',
        content_based_games=content_based_games,
        collaborative_games=collaborative_games,
        popular_games=popular_games,
    )



@bp.route('/forum', methods=['GET', 'POST'])
@login_required
def forum():
    if request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        post = Post(title=title, content=content, user_id=current_user.id)
        db.session.add(post)
        db.session.commit()
        flash('Your post has been added!', 'success')
        return redirect(url_for('main.forum'))
    posts = Post.query.all()
    return render_template('forum.html', posts=posts)


@bp.route('/search', methods=['GET'])
def search():
    query = request.args.get('query')
    games = Game.query.filter(Game.title.contains(query) | Game.description.contains(query)).all()
    return render_template('search_results.html', games=games)


@bp.route('/games/<int:game_id>', methods=['GET', 'POST'])
@login_required
def game_detail(game_id):
    game = Game.query.get_or_404(game_id)
    purchased = game in current_user.purchased_games

    if request.method == 'POST':
        if request.form.get('rating'):
            rating = request.form.get('rating')
            text = request.form.get('review')
            review = Review(rating=rating, text=text, user_id=current_user.id, game_id=game_id)
            db.session.add(review)
            db.session.commit()
            flash('평가가 추가되었습니다.', 'success')
            return redirect(url_for('main.game_detail', game_id=game_id))

    return render_template('game_detail.html', game=game, purchased=purchased)


@bp.route('/purchase/<int:game_id>', methods=['POST'])
@login_required
def purchase_game(game_id):
    game = Game.query.get_or_404(game_id)
    if game not in current_user.purchased_games:
        purchase = Purchase(user_id=current_user.id, game_id=game_id)
        db.session.add(purchase)
        db.session.commit()
        flash('게임을 구매했습니다.', 'success')
    return redirect(url_for('main.game_detail', game_id=game_id))


@bp.route('/rate/<int:game_id>', methods=['POST'])
@login_required
def rate_game(game_id):
    game = Game.query.get_or_404(game_id)
    rating = request.form.get('rating')
    review_text = request.form.get('review')
    review = Review(rating=rating, text=review_text, user_id=current_user.id, game_id=game_id)
    db.session.add(review)
    db.session.commit()
    flash('평가가 추가되었습니다.', 'success')
    return redirect(url_for('main.game_detail', game_id=game_id))


@bp.route('/delete_review/<int:review_id>', methods=['POST'])
@login_required
def delete_review(review_id):
    review = Review.query.get_or_404(review_id)
    if review.author != current_user:
        flash('You cannot delete this review.', 'danger')
        return redirect(url_for('main.game_detail', game_id=review.game_id))
    db.session.delete(review)
    db.session.commit()
    flash('The review has been deleted.', 'success')
    return redirect(url_for('main.game_detail', game_id=review.game_id))


@bp.route('/add_review/<int:game_id>', methods=['POST'])
@login_required
def add_review(game_id):
    game = Game.query.get_or_404(game_id)
    rating = request.form['rating']
    text = request.form['review']

    review = Review(rating=rating, text=text, author=current_user, game=game)
    db.session.add(review)
    db.session.commit()
    flash('Your review has been added!', 'success')
    return redirect(url_for('main.game_detail', game_id=game.id))


@bp.route("/review/<int:review_id>/edit", methods=['GET', 'POST'])
@login_required
def edit_review(review_id):
    review = Review.query.get_or_404(review_id)
    if review.author != current_user:
        flash('You are not authorized to edit this review.', 'danger')
        return redirect(url_for('main.game_detail', game_id=review.game_id))

    if request.method == 'POST':
        review.rating = request.form['rating']
        review.text = request.form['text']
        db.session.commit()
        flash('Your review has been updated!', 'success')
        return redirect(url_for('main.game_detail', game_id=review.game_id))

    return render_template('edit_review.html', review=review)